#define PORT 8080
#define threadPoolSize 0
#define numSetsInCache 20
#define sizeOfSet 20